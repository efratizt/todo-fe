import React from "react";
import Home from "./components/home";

import "./App.css";

function App() {
  return (
    <div className="container">
      <Home />
    </div>
  );
}

export default App;
